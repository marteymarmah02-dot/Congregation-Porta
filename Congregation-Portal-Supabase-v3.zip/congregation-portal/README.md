# Congregation Portal — Supabase edition (phone-only setup)

This keeps the existing HTML app and its modules while replacing Firebase cloud auth/storage with Supabase. You do not need Node.js for this browser/PWA version.

## Included
- Existing overview, meetings/events, schedules, Life & Ministry, weekend meeting, away talks, field service, public witnessing, territories, assignments, publishers, groups, information board, tasks/reports, settings and backups.
- Literature: the congregation literature app (requests, shipments, inventory, rotation, guidelines) now lives inside this app under Literature. Editors can change it, viewers can read it, and it syncs through Supabase as one shared record.
- Local/offline mode remains available.
- Supabase email/password sign-in, optional Google OAuth, pending/approved/blocked user status, admin/editor/viewer roles.
- Shared cloud records and Realtime refresh when enabled.
- Row Level Security starter schema.

## Setup on Android only
1. In Chrome, open https://supabase.com and create a free project. Save the database password privately.
2. In the project, open SQL Editor → New query. Open `supabase-schema.sql` from this package using a text editor, copy all its contents, paste into SQL Editor, and run. If you already ran an older version, run this one again: it is safe to repeat and adds the witnessing reservation function.
3. Open Authentication → Providers. Enable Email. If you want Google sign-in, configure Google OAuth separately in Supabase and Google Cloud; it is optional.
4. Open Project Settings → API. Copy the Project URL and the publishable key (or legacy anon key). NEVER use a `service_role` or secret key in the app.
5. Host the files on HTTPS. Easiest phone-only option: create a GitHub repository in Chrome, upload `index.html`, `manifest.json`, `sw.js`, `icon.svg`, `icon-192.png`, `icon-512.png` and `icon-maskable-512.png` from this folder (plus the SQL file if you want it stored in the repo), then enable Settings → Pages. For private congregation data, use a private repository if your hosting plan supports it, or use another private-access hosting setup; remember that static HTML source itself is visible to visitors.
6. Open your hosted app URL, choose Connect Supabase cloud, and enter the Project URL and publishable/anon key.
7. Create the first account from the app. Supabase creates it as `pending` by design.
8. In Supabase SQL Editor, run the following query, replacing the email with your exact sign-in email:

   `update public.profiles set role = 'admin', status = 'approved' where lower(email) = lower('your-email@example.com');`

9. Sign out and sign in again. Your account should show Admin. New users can register, then you can approve them and set their role in Settings → Users & roles.
10. Realtime is switched on by the SQL script itself. To check, open Supabase Dashboard → Database → Publications and confirm `app_records` is ticked under `supabase_realtime`.
11. Load your congregation data once. Sign in as admin, open Settings → Backup → Import backup, and pick `private-congregation-data.json` (it is sent to you separately, not in this package). Choose Merge. It adds the service groups, publishers, the schedules, field service and public witnessing programs, and your literature starting data (congregation name, coordinator, rotation).
12. In Chrome on Android, use ⋮ → Add to Home screen / Install app.

## Keep names out of the hosted files
This package contains no congregation names. Your names and schedules live in `private-congregation-data.json`, which you import after signing in, so they are stored only in your Supabase database behind sign-in. Do not upload that JSON file to GitHub or any public site. A public GitHub Pages site shows every file in it to anyone with the link.

## Brothers and sisters
Each publisher has a Brother or Sister setting. Open Brothers & sisters (under More, or on the Publishers page) to see brothers on one side and sisters on the other, and tap a name to move it. Pairing keeps brothers with brothers and sisters with sisters. In a group, use Pair sisters and then Pair brothers, or Pair all. Family can still be paired across sides with "Always pair with" on a publisher's record. To set everyone at once, import `private-brothers-sisters.json` in Settings → Backup → Restore / import.

## Pairings for field service
Open Pairings. Each group has a Pair button: one tap makes fair pairs from the members who are present, never pairing away publishers and rotating partners so people do not keep working with the same person. You can see and edit every member, untick anyone absent, change names in a pair, lock a pair, and save it. Odd groups get one group of three. On a publisher's record, "Always pair with" keeps family together. The Ministry tab combines every group into one list, or mixes all groups together, and you can copy, print or send each person their partner.

## If a page does not open
Every page now shows a clear message instead of staying blank. Take a screenshot of the message and send it so it can be fixed. If an old version keeps showing after an update, close the app fully and open it again twice, or clear the site data for the app in your browser settings.

## Updating the groups later
When you get a new groups document, send it to Claude and you will receive a small private JSON file. Import it in Settings → Backup → Import backup. The app moves each publisher by name into their new group, fixes spellings, and keeps phone numbers, roles and everything else you entered.

## What changed in this version
- Groups update by name from a private file. Names are matched even when spelled slightly differently.
- Pending and blocked accounts now see a clear message instead of a blank sign-in screen.
- The hourly sign-in token refresh no longer rebuilds the app or reopens the live connection.
- Only approved accounts can enter, including admins.
- Approved viewers can reserve public witnessing places through a safe database function.
- The service worker now loads the newest version of the app when you are online, so updates show up without clearing the cache.
- PNG icons were added so Chrome offers the install option reliably.

## Important security notes
- Never paste a Supabase secret/service_role key into the HTML. The browser must use only the publishable key (or legacy anon key).
- The SQL uses Row Level Security and starts all new users as pending. The first administrator is promoted manually so no stranger can claim the admin role.
- Static HTML/PWA source can be viewed by anyone who can load it. Do not include real congregation records, passwords, or private information in the source code. Use HTTPS and test with sample data before importing actual records.
- Admin removal changes a profile status to `blocked`; it does not delete the user's Supabase Auth identity.
- Realtime refresh is not a substitute for backups. Export backups regularly and test restoration.
- Review policies with a knowledgeable administrator before storing confidential information.

## Existing local records
The app keeps local data in browser storage. Export a backup from Settings before switching devices. This package does not automatically migrate old Firebase records. Use Settings → Backup & restore to import a JSON backup into the Supabase workspace after signing in with an approved editor/admin account.

## Official documentation
- Browser client: https://supabase.com/docs/reference/javascript/initializing
- Auth: https://supabase.com/docs/guides/auth
- Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Google OAuth: https://supabase.com/docs/guides/auth/social-login/auth-google
