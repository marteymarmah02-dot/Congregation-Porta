-- Congregation Manager — Supabase setup
-- Run this whole script in Supabase Dashboard → SQL Editor → New query.
-- Do NOT put a service_role/secret key in the HTML app.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'viewer' check (role in ('admin','editor','viewer')),
  status text not null default 'pending' check (status in ('pending','approved','blocked')),
  created_at timestamptz not null default now()
);

create table if not exists public.app_records (
  collection_name text not null,
  record_id text not null,
  payload jsonb not null default '{}'::jsonb,
  owner_email text,
  updated_at timestamptz not null default now(),
  primary key (collection_name, record_id)
);

create index if not exists app_records_collection_idx on public.app_records(collection_name);
create index if not exists app_records_owner_idx on public.app_records(owner_email);

create or replace function public.cm_is_approved()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles p where p.id = auth.uid() and p.status = 'approved') $$;

create or replace function public.cm_role()
returns text language sql stable security definer set search_path = public
as $$ select coalesce((select p.role from public.profiles p where p.id = auth.uid() and p.status = 'approved'), 'viewer') $$;

create or replace function public.cm_is_editor()
returns boolean language sql stable security definer set search_path = public
as $$ select public.cm_role() in ('admin','editor') $$;

alter table public.profiles enable row level security;
alter table public.app_records enable row level security;

-- A signed-in user can read only their own profile; admins can read all profiles.
drop policy if exists "profile self or admin read" on public.profiles;
create policy "profile self or admin read" on public.profiles for select to authenticated
using (id = auth.uid() or public.cm_role() = 'admin');

-- Users may update their own email field only in principle, but profile role/status
-- changes must be made by an approved admin. This policy limits client updates to admins.
drop policy if exists "admin manages profiles" on public.profiles;
create policy "admin manages profiles" on public.profiles for update to authenticated
using (public.cm_role() = 'admin') with check (public.cm_role() = 'admin');

-- Profile creation is done by the trusted auth trigger below, not from the browser.
create or replace function public.cm_new_user_profile()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles(id,email,role,status)
  values(new.id, coalesce(new.email,''), 'viewer', 'pending')
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists cm_on_auth_user_created on auth.users;
create trigger cm_on_auth_user_created after insert on auth.users
for each row execute procedure public.cm_new_user_profile();

-- Approved users can read shared records; private personal records are visible only
-- to their owner unless the user is an editor/admin.
drop policy if exists "approved users read records" on public.app_records;
create policy "approved users read records" on public.app_records for select to authenticated
using (
  public.cm_is_approved() and
  (collection_name not in ('activity','fsr','literature','away')
   or public.cm_is_editor() or owner_email = (select email from public.profiles where id = auth.uid()))
);

drop policy if exists "approved editors write shared records" on public.app_records;
create policy "approved editors write shared records" on public.app_records for insert to authenticated
with check (
  public.cm_is_approved() and (
    public.cm_is_editor() or
    (collection_name in ('activity','fsr','literature','away') and owner_email = (select email from public.profiles where id = auth.uid()))
  )
);

drop policy if exists "approved editors update shared records" on public.app_records;
create policy "approved editors update shared records" on public.app_records for update to authenticated
using (
  public.cm_is_approved() and (
    public.cm_is_editor() or
    (collection_name in ('activity','fsr','literature','away') and owner_email = (select email from public.profiles where id = auth.uid()))
  )
)
with check (
  public.cm_is_approved() and (
    public.cm_is_editor() or
    (collection_name in ('activity','fsr','literature','away') and owner_email = (select email from public.profiles where id = auth.uid()))
  )
);

drop policy if exists "approved editors delete shared records" on public.app_records;
create policy "approved editors delete shared records" on public.app_records for delete to authenticated
using (
  public.cm_is_approved() and (
    public.cm_is_editor() or
    (collection_name in ('activity','fsr','literature','away') and owner_email = (select email from public.profiles where id = auth.uid()))
  )
);

grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.app_records to authenticated;

-- Public witnessing: any approved user may reserve or release a place.
-- This function can change only the "people" list of a witnessing slot (pwslot), nothing else.
create or replace function public.cm_pw_reserve(p_record text, p_people jsonb)
returns void language plpgsql security definer set search_path = public
as $$
begin
  if not public.cm_is_approved() then raise exception 'Account is not approved'; end if;
  if jsonb_typeof(coalesce(p_people, '[]'::jsonb)) <> 'array' then raise exception 'people must be a list'; end if;
  update public.app_records
     set payload = jsonb_set(payload, '{people}', coalesce(p_people, '[]'::jsonb), true), updated_at = now()
   where collection_name = 'pwslot' and record_id = p_record;
end; $$;
revoke all on function public.cm_pw_reserve(text, jsonb) from public;
grant execute on function public.cm_pw_reserve(text, jsonb) to authenticated;

-- Realtime sync: switch it on for app_records automatically (safe to run again).
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables
                     where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'app_records') then
    alter publication supabase_realtime add table public.app_records;
  end if;
end $$;
